CSCI 1300
Project 2 by Abiral Tuladhar
12/7/23

Hello!
This project was fun, heres how to get it fully working based on particularly your operating system.

This project contains 3 header files, 3 implementation files, as well as a folder for text files to reference character
as well as candy data and hidden treasure (riddle) data.

- board.h, board.cpp 		:	Contains all board and player movement information
- candy.h, candy.cpp 		:	Contains information on Candy Struct and Candy Store
- player.h, player.cpp 		:	Contains information on Player Class

Within main.cpp is the driver file, where much of the actual game is being held while being structer by the classes and structs.
(The main game loop, as well as the functions to read and write file data is held here)

The only thing one needs to be weary of when compiling my version of this project is specifically on line 674
By default I program on Windows OS, which means to clear the screen I use system("cls"), for MacOS users that would
also like to compile this, please change this line to system("clear").

For the compilation line, please follow as standard and include all .cpp files used.

(Don't forget the semicolons of course)

Thank you for your time.

